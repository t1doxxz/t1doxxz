﻿namespace Dox.UI.AsciiMenu.DoxBinLayouts
{
    public class CoreModel
    {
        public static void GetLayouts()
        {
        }
    }
}