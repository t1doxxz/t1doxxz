﻿using Leaf.xNet;

namespace Dox.Components.UsernameGrabber.Modules
{
    internal class Facebook
    {
        public static void Get(string Username)
        {
            using (HttpRequest req = new HttpRequest())
            {
                // API patched (03/02/2023) // Trying to find bypass or workaround.
            }
        }
    }
}