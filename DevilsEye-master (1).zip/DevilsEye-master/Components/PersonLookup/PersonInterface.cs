﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dox.Components.PersonLookup
{
    internal interface PersonInterface
    {
        /*
         * The entry point for the person lookup module
         */
        public static void GetPerson()
        {

        }

        /*
         * Fetch the results from the person lookup
         */
        private static void FetchResults()
        {

        }

        /*
         * Get the person by their ID
         */
    }
}
