﻿namespace Dox.Components.PhoneDorker.ReverseLookup
{
    internal interface ReverseInterfance
    {
        public static void GetNumber()
        {

        }
    }
}
